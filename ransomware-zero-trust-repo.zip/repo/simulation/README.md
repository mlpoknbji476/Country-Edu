# Simulation / Proof of Concept

Runnable Python demos (standard library only) for three mechanisms from the main design document.
**All data is synthetic. This is a simulation, not a real incident or real malware.**

| Script | Design section | What it demonstrates |
|---|---|---|
| `backup_verify.py` | Sec. 14 | 5-gate backup verification (immutability, hash vs out-of-band catalog, timeline bracketing, entropy scan, restore test) on 12 synthetic backups with injected tampering, lock override and encrypted content |
| `detect_and_respond.py` | Sec. 5, 11, 12 | Z-score insider detection and entropy/rate ransomware detection, mapped to the kill-switch hierarchy with clinical-safe quarantine and two-person approval |
| `run_demo.py` | | Runs both, writes `output/run_log.txt` |

Run: `python3 run_demo.py`

Outputs (from an actual run): `output/run_log.txt`, `output/backup_verification.json`, `output/detection_and_response.json`
