"""Section 14 PoC: multi-gate verification of synthetic backup sets. No real data."""
import os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output"); os.makedirs(OUT, exist_ok=True)
import hashlib, math, os, random, json
from datetime import date, timedelta

random.seed(7)
FIRST_IOC = date(2026, 9, 24)          # earliest known compromise (simulated)
SAFETY_MARGIN = timedelta(days=7)      # dormant-persistence margin
ENTROPY_LIMIT = 7.5                    # bits/byte; text ~4-5, encrypted ~8

def entropy(b: bytes) -> float:
    if not b: return 0.0
    n = len(b); freq = [0]*256
    for x in b: freq[x] += 1
    return -sum(c/n*math.log2(c/n) for c in freq if c)

def text_blob(i): return (f"patient_record_{i} vitals ok; meds list; notes " * 60).encode()

def make_backup(day, encrypted=False, lock=True, tamper=False):
    files = {f"ehr/rec_{i}.dat": (os.urandom(3000) if encrypted and i % 2 == 0 else text_blob(i)) for i in range(8)}
    return {"date": day, "files": files, "object_lock": lock, "override_events": 0}

def build():
    d0 = date(2026, 9, 15)
    sets = [make_backup(d0 + timedelta(days=i)) for i in range(12)]
    catalog = {b["date"].isoformat(): {k: hashlib.sha256(v).hexdigest() for k, v in b["files"].items()} for b in sets}
    # simulate attacker effects AFTER catalog was stored out-of-band
    sets[7]["files"]["ehr/rec_3.dat"] = b"TAMPERED"                       # silent modification
    sets[8]["object_lock"] = False; sets[8]["override_events"] = 2        # retention lock disabled
    for i in (10, 11):                                                    # ransomware-encrypted content
        sets[i] = make_backup(sets[i]["date"], encrypted=True)
        catalog[sets[i]["date"].isoformat()] = {k: hashlib.sha256(v).hexdigest() for k, v in sets[i]["files"].items()}
    return sets, catalog

def verify(b, catalog):
    key = b["date"].isoformat(); r = {}
    r["G1_immutability"] = b["object_lock"] and b["override_events"] == 0
    r["G2_integrity"] = all(hashlib.sha256(v).hexdigest() == catalog[key][k] for k, v in b["files"].items())
    r["G3_timeline"] = b["date"] < FIRST_IOC - SAFETY_MARGIN
    r["G4_malware_entropy"] = all(entropy(v) < ENTROPY_LIMIT for v in b["files"].values())
    r["G5_restore_test"] = len(b["files"]) == 8 and all(len(v) > 100 for v in b["files"].values())
    return r

if __name__ == "__main__":
    sets, cat = build(); out = []; trusted = []
    print(f"First IOC: {FIRST_IOC}  | safety margin: {SAFETY_MARGIN.days}d\n")
    hdr = f"{'Backup':<12}{'G1 lock':<9}{'G2 hash':<9}{'G3 time':<9}{'G4 entropy':<12}{'G5 restore':<12}VERDICT"
    print(hdr); print("-"*len(hdr))
    for b in sets:
        r = verify(b, cat); ok = all(r.values())
        if ok: trusted.append(b["date"].isoformat())
        f = lambda x: "PASS" if x else "FAIL"
        print(f"{b['date']!s:<12}{f(r['G1_immutability']):<9}{f(r['G2_integrity']):<9}{f(r['G3_timeline']):<9}{f(r['G4_malware_entropy']):<12}{f(r['G5_restore_test']):<12}{'TRUSTED RESTORE POINT' if ok else 'REJECTED'}")
        out.append({"date": b["date"].isoformat(), **r, "trusted": ok})
    print(f"\nTrusted restore points: {len(trusted)}/{len(sets)} -> latest usable: {trusted[-1] if trusted else 'NONE'}")
    json.dump(out, open(os.path.join(OUT, "backup_verification.json"), "w"), indent=2)
