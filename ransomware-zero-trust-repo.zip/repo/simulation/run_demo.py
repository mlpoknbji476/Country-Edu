import os, subprocess, sys, datetime
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "output")
os.makedirs(OUT, exist_ok=True)
with open(os.path.join(OUT, "run_log.txt"), "w") as f:
    f.write(f"Run at {datetime.datetime.now().isoformat(timespec='seconds')} | python {sys.version.split()[0]}\n\n")
    for s in ("backup_verify.py", "detect_and_respond.py"):
        f.write(f"$ python {s}\n")
        r = subprocess.run([sys.executable, os.path.join(HERE, s)], capture_output=True, text=True, cwd=HERE)
        f.write(r.stdout + r.stderr + "\n"); print(r.stdout, r.stderr)
