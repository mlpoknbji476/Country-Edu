"""Sections 5/11/12 PoC: behavioral anomaly detection -> kill-switch decision engine (synthetic events)."""
import os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output"); os.makedirs(OUT, exist_ok=True)
import random, statistics, math, json
from dataclasses import dataclass
random.seed(42)

# ---------- synthetic telemetry ----------
users = [f"clin_{i:02d}" for i in range(20)] + ["u_insider"]
def baseline():  # records accessed per hour, normal working hours
    return {u: [max(0, int(random.gauss(25, 6))) for _ in range(30)] for u in users}
hist = baseline()
today = {u: max(0, int(random.gauss(25, 6))) for u in users}
today["u_insider"] = 410                      # off-hours bulk patient-record access
hosts = {f"srv_{i:02d}": {"mods_per_min": random.randint(5, 40), "entropy": round(random.uniform(4.2, 5.4), 2), "clinical": i in (1, 2)} for i in range(8)}
hosts["srv_05"] = {"mods_per_min": 900, "entropy": 7.9, "clinical": False}   # ransomware-like burst
hosts["srv_02"] = {"mods_per_min": 850, "entropy": 7.8, "clinical": True}    # same, on a clinical host

@dataclass
class Alert: kind: str; subject: str; score: float; detail: str; clinical: bool = False

# ---------- detection ----------
alerts = []
for u, series in hist.items():
    mu, sd = statistics.mean(series), statistics.pstdev(series) or 1
    z = (today[u] - mu) / sd
    if z > 4: alerts.append(Alert("INSIDER_BULK_ACCESS", u, round(z, 1), f"{today[u]} records/h vs baseline {mu:.0f}"))
for h, m in hosts.items():
    if m["mods_per_min"] > 300 and m["entropy"] > 7.5:
        alerts.append(Alert("RANSOMWARE_BEHAVIOR", h, m["entropy"], f"{m['mods_per_min']} file mods/min, entropy {m['entropy']}", m["clinical"]))

# ---------- kill-switch decision engine (Section 5) ----------
LEVELS = {"L1": "Suspend identity + revoke sessions", "L2": "Quarantine host/workload",
          "L3": "Block lateral protocol (SMB/RDP/WinRM)", "L4": "Freeze privileged tier"}
def decide(a: Alert):
    if a.kind == "INSIDER_BULK_ACCESS":
        return ["L1"], "Silent evidence capture first (Sec 11); L1 executes after snapshot"
    if a.kind == "RANSOMWARE_BEHAVIOR":
        if a.clinical:
            return ["L3", "L2*"], "CLINICAL-SAFE QUARANTINE: allow-list EHR/HL7 flows only, snapshot, fail over to verified replica"
        return ["L2", "L3"], "Full host quarantine via EDR/switch-port isolation"
    return ["L0"], "Monitor"

print("=== DETECTIONS ===")
log = []
for a in alerts:
    levels, note = decide(a)
    approval = "AUTO (SOAR)" if all(l.strip("*") in ("L1", "L2", "L3") for l in levels) else "TWO-PERSON APPROVAL"
    print(f"[ALERT] {a.kind:<22} subject={a.subject:<10} score={a.score:<6} {a.detail}")
    print(f"        -> actions: {', '.join(levels)} | authority: {approval}\n        -> {note}")
    log.append({**a.__dict__, "actions": levels, "authority": approval, "note": note})
# propagation-stopping escalation check
if sum(1 for a in alerts if a.kind == "RANSOMWARE_BEHAVIOR") >= 2:
    print("\n[ESCALATE] >=2 hosts encrypting -> L4 (freeze privileged tier) + L6 (pause replication) proposed")
    print("           authority: TWO-PERSON APPROVAL (Incident Commander + Clinical Lead veto check)")
    log.append({"escalation": ["L4", "L6"], "authority": "TWO-PERSON APPROVAL"})
json.dump(log, open(os.path.join(OUT, "detection_and_response.json"), "w"), indent=2)
injected = {"u_insider", "srv_05", "srv_02"}
raised = {a.subject for a in alerts}
print(f"\nTotal alerts: {len(alerts)} | injected anomalies: {len(injected)} | detected: {len(raised & injected)} | false positives: {len(raised - injected)} (computed over 21 users + 8 hosts)")
