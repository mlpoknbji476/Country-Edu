# Active Multi-Region Ransomware + Insider Threat During Zero-Trust Enforcement

> **Scenario type:** Cyber security architecture and incident response design
> **Author:** G Abhiram
> **Domain:** Healthcare (life-critical availability), hybrid cloud, identity federation

---

## Table of Contents

0. [Repository Structure and Proof of Concept](#repository-structure)
1. [Problem Summary](#1-problem-summary)
2. [Constraints and Design Principles](#2-constraints-and-design-principles)
3. [Incident Command Timeline](#3-incident-command-timeline)
4. [Zero-Trust Pivot Strategy (Mid-Incident)](#4-zero-trust-pivot-strategy-mid-incident)
5. [Kill-Switch Hierarchy](#5-kill-switch-hierarchy)
6. [Identity Plane Protection Model](#6-identity-plane-protection-model)
7. [Live Ransomware Containment Architecture](#7-live-ransomware-containment-architecture)
8. [Microsegmentation Enforcement Model](#8-microsegmentation-enforcement-model)
9. [Credential Revocation and Reissuance Strategy](#9-credential-revocation-and-reissuance-strategy)
10. [Secure Identity Re-Bootstrap Process](#10-secure-identity-re-bootstrap-process)
11. [Insider Threat Isolation Workflow](#11-insider-threat-isolation-workflow)
12. [Behavioral Anomaly Detection Strategy](#12-behavioral-anomaly-detection-strategy)
13. [Forensic-Safe Containment](#13-forensic-safe-containment)
14. [Immutable Backup Verification Method](#14-immutable-backup-verification-method)
15. [Clean-Room Recovery Pipeline](#15-clean-room-recovery-pipeline)
16. [Cross-Region Failover Security Validation](#16-cross-region-failover-security-validation)
17. [Recovery Trust Chain Reconstruction](#17-recovery-trust-chain-reconstruction)
18. [Operational Continuity Balancing](#18-operational-continuity-balancing)
19. [Regulatory Reporting Track](#19-regulatory-reporting-track)
20. [Constraint-to-Control Traceability Matrix](#20-constraint-to-control-traceability-matrix)
21. [Metrics, Risks and Trade-offs](#21-metrics-risks-and-trade-offs)
22. [Appendices: Run Output, Source Code, Results](#appendix-a-proof-of-concept-run-output)

---

## Repository Structure

```
.
├── README.md                    <- this design document
├── docs/
│   └── run-screenshot.png       <- terminal proof of the simulation run
└── simulation/                  <- runnable proof of concept (standard library only)
    ├── backup_verify.py         <- Sec. 14: multi-gate backup verification
    ├── detect_and_respond.py    <- Sec. 5, 11, 12: anomaly detection + kill-switch engine
    ├── run_demo.py              <- runs both, writes output/run_log.txt
    └── output/                  <- logs and JSON from an actual run
```

## Proof of Concept (Simulation)

Three mechanisms from this design are implemented as runnable code on **synthetic data only** (no real malware, no real patient data).

```bash
python3 simulation/run_demo.py
```

![Simulation run](docs/run-screenshot.png)

| Result | Outcome |
|---|---|
| Backup verification (Sec. 14) | 2 of 12 synthetic backups certified as trusted restore points; the rest were rejected for tampering, a disabled retention lock, encrypted content, or predating the compromise margin |
| Anomaly detection (Sec. 12) | 3 of 3 injected anomalies detected, 0 false positives |
| Kill-switch engine (Sec. 5) | Insider case triggers L1 after evidence capture; clinical host gets clinical-safe quarantine; two encrypting hosts trigger a proposed L4 + L6 under two-person approval |

See [`simulation/README.md`](simulation/README.md) for details.

---

## 1. Problem Summary

The organization is **partway through a zero-trust migration** (segmentation incomplete, legacy systems still present) when four things happen at once:

| Signal | Meaning |
|---|---|
| Insider credential misuse | A valid identity is being abused, so perimeter logic will not help |
| Ransomware spreading across hybrid infrastructure | Encryption or staging is active on-prem and in cloud |
| Privileged access escalation attempts | Attackers are moving toward domain, IdP or key control |
| East-west traffic bypassing segmentation | Segmentation gaps are being exploited for lateral movement |

**Crown-jewel systems:**

- Healthcare records platform (EHR/EMR), where availability is life-critical
- Identity federation services (IdP, SSO, SAML/OIDC, directory)
- Multi-region data replication pipelines (which can also *replicate the damage*)

**Core insight:** The attacker moves with *legitimate credentials*, so the identity plane is both the primary attack path and the primary control point. The response is therefore **identity-centric containment**, not network shutdown.

---

## 2. Constraints and Design Principles

| Constraint | Resulting design principle |
|---|---|
| Patient data availability is life-critical | **Fail-operational for clinical paths.** Read-only clinical mode is preferred over downtime. |
| No full network isolation allowed | **Surgical containment.** Contain by identity, workload and flow, never by blanket cut-off. |
| IAM infrastructure must remain online | **Protect and rebuild identity in parallel** (blue/green identity plane). Never take it down. |
| Backup integrity uncertain | **Trust nothing until verified.** Multi-stage verification before any restore. |
| Attack propagates via legitimate credentials | **Assume credential compromise.** Revoke, shorten and re-bind sessions and tokens. |
| Encryption keys may be partially exposed | **Rotate the key hierarchy** (KEK first, then DEK re-wrap). Treat exposed keys as burned. |
| Legacy systems lack endpoint telemetry | **Compensate at the network and identity layers** (NDR, flow logs, proxy and jump-host brokering). |
| Segmentation incomplete | **Overlay enforcement** (host firewalls, SDN policy, ACLs) in priority order. |
| Regulatory clock already started | **Parallel compliance track** with evidence preserved from minute zero. |
| 99.99% SLA (~52.6 min downtime/year, ~4.4 min/month) | **Rolling, region-by-region operations.** No big-bang changes. |

**Guiding principles**

1. **Contain the identity, not the network.**
2. **Preserve life-critical function first, then evidence, then convenience.**
3. **Every action has a reversibility rating** (see the kill-switch hierarchy).
4. **Nothing is trusted because of where it sits**: verify identity, device, workload and behavior each time.
5. **Rebuild trust from a hardware-rooted anchor**, not from the compromised environment.

---

## 3. Incident Command Timeline

```mermaid
flowchart LR
    A["T+0 to 15 min<br/>Triage and Freeze<br/>Declare incident, snapshot evidence,<br/>lock privileged tier"] --> B["T+15 to 60 min<br/>Surgical Containment<br/>Revoke sessions, quarantine hosts,<br/>enforce emergency segmentation"]
    B --> C["T+1 to 6 h<br/>Identity Stabilization<br/>Rotate high-value secrets, stand up<br/>clean identity plane"]
    C --> D["T+6 to 48 h<br/>Clean-Room Recovery<br/>Verify backups, rebuild<br/>systems, staged reconnect"]
    D --> E["T+2 to 14 d<br/>Trust Reconstruction<br/>Cross-region validation,<br/>hardening, lessons learned"]
```

**Roles (Incident Command System)**

| Role | Responsibility |
|---|---|
| Incident Commander (CISO delegate) | Owns decisions, authorizes kill-switch levels |
| Clinical Continuity Lead | Represents patient safety, holds veto on actions affecting clinical systems |
| Identity Lead | Runs revocation, IdP rebuild and re-bootstrap |
| Network/Cloud Lead | Runs segmentation overlay and flow control |
| Forensics Lead | Evidence, chain of custody, root cause |
| Legal/Compliance/Privacy Officer | Regulatory clock, notifications |
| HR + Legal (restricted) | Insider case handling (need-to-know only) |
| Comms Lead | Staff, patient, regulator and media messaging |

Out-of-band communication (a separate chat and phone bridge not dependent on corporate identity) is established at **T+0**, because the corporate directory and email must be assumed monitored.

---

## 4. Zero-Trust Pivot Strategy (Mid-Incident)

The aim is to **accelerate the zero-trust transition only on the paths the attacker is using**, rather than finishing the whole migration during an incident.

### 4.1 Pivot approach: "Protect surfaces first, in blast-radius order"

```mermaid
flowchart TD
    S1["1. Identity plane<br/>(IdP, directory, PAM, KMS/HSM)"] --> S2["2. Clinical crown jewels<br/>(EHR, replication, key stores)"]
    S2 --> S3["3. Admin and management paths<br/>(RDP/SSH/WinRM, hypervisor, backup consoles)"]
    S3 --> S4["4. Shared services<br/>(DNS, file, print, patching)"]
    S4 --> S5["5. General user and legacy zones"]
```

### 4.2 Pivot mechanics

| Step | Action |
|---|---|
| Default-deny for privileged protocols | Block SMB admin shares, RDP, WinRM, SSH, PsExec and WMI between workstation and server tiers unless brokered |
| Introduce policy enforcement points (PEPs) | Deploy identity-aware proxy or ZTNA in front of admin paths (jump host / PAM broker) |
| Continuous evaluation | Every session is scored (user risk + device posture + behavior). Step-up or terminate on drift. |
| Allow-list clinical flows | Map and pin known-good EHR, HL7/FHIR, PACS and replication flows, then deny the rest by default around them |
| Time-boxed exceptions | Every exception carries an expiry (default 4 hours), an owner and an audit record |

### 4.3 What is deliberately *not* done

- No "big-bang" enforcement across all segments (risk of clinical outage).
- No forced MFA re-enrollment for the entire user base at once (helpdesk and clinical friction). It is staged by risk tier.

---

## 5. Kill-Switch Hierarchy

Kill switches are ordered by **blast radius and reversibility**. Higher levels need higher authority and are used only when lower levels fail to stop propagation.

| Level | Kill switch | Scope | Reversibility | Authority | Clinical impact |
|---|---|---|---|---|---|
| **L0** | Alert and enhanced logging | Observation only | Full | SOC Lead | None |
| **L1** | Suspend a single identity (user/service account); revoke its sessions and tokens | 1 identity | Full | SOC Lead | Very low |
| **L2** | Quarantine a single host or workload (EDR isolation, VLAN/SDN tag, security group swap) | 1 asset | Full | SOC Lead + Sys Owner | Low; use "clinical-safe quarantine" for critical assets |
| **L3** | Block a specific flow/protocol between segments (e.g., SMB east-west) | Protocol or segment pair | High | Incident Commander | Low to medium |
| **L4** | Freeze privileged tier (disable standing admin, enforce PAM-only, JIT approval by IC) | All admin identities | High | Incident Commander | Medium (slows change) |
| **L5** | Sever a compromised segment or site link, with clinical-allow rules preserved | 1 segment | Medium | IC + Clinical Lead | Medium to high (degraded mode) |
| **L6** | Pause cross-region replication (stop damage propagation, preserve last-known-good) | Replication pipelines | Medium | IC + Data Owner | Medium (RPO grows) |
| **L7** | Revoke and rotate federation trust (SAML signing cert, OIDC keys, KRBTGT double reset) | Whole identity fabric | Low | IC + CISO + CIO | High, needs the staged plan in Section 10 |
| **L8** | Region isolation (last resort) | One region | Low | Executive crisis team | Very high, only if another region can carry clinical load |

**Rules for using the hierarchy**

1. **Start at the lowest level that stops the observed behavior.** Escalate only with evidence.
2. **Clinical Lead veto:** Any L5 or higher action affecting patient-facing systems needs an explicit "safe-to-proceed" or a documented override by the IC.
3. **Two-person rule** for L4 and above.
4. **Pre-staged automation** (SOAR playbooks) exists for L1 to L3 so they execute in seconds. L4 and above are human-approved.
5. **Every switch has a documented "un-kill" procedure** and a review timer.
6. **Ordering note:** L6 (pause replication) is applied *before* L7/L8 because it protects clean copies in other regions cheaply.

---

## 6. Identity Plane Protection Model

Identity is the control plane that both attacker and defender depend on. The model has **four rings**.

```mermaid
flowchart TB
    subgraph R0["Ring 0: Trust Roots"]
        HSM["HSM / KMS root keys"]
        CA["Offline root CA"]
        BG["Break-glass FIDO2 accounts"]
    end
    subgraph R1["Ring 1: Identity Infrastructure"]
        IDP["IdP / Federation"]
        DIR["Directory / Domain Controllers"]
        PAM["PAM vault"]
    end
    subgraph R2["Ring 2: Privileged and Service Identities"]
        ADM["Admin accounts"]
        SVC["Service accounts and workload identities"]
        API["API keys / tokens / secrets"]
    end
    subgraph R3["Ring 3: Workforce and Clinical Users"]
        USR["Staff, clinicians, contractors"]
    end
    R0 --> R1 --> R2 --> R3
```

### 6.1 Protections per ring

| Ring | Protections |
|---|---|
| **Ring 0** | Offline/air-gapped custody; HSM-backed with quorum (M-of-N) approval; no network path from general zones; used only for re-bootstrap |
| **Ring 1** | Dedicated management enclave; only PAM-brokered admin access from hardened Privileged Access Workstations (PAWs); read-only monitoring replicas; continuous integrity monitoring of directory objects, federation trust and signing certificates; change freeze enforced |
| **Ring 2** | Tiered admin model (Tier 0/1/2, no credential crossing tiers); JIT/JEA elevation with approval and recording; service accounts moved to managed identities or short-lived certificates; secrets in vault with automatic rotation |
| **Ring 3** | Risk-based conditional access; token lifetime shortening; step-up MFA (phishing-resistant for high risk); session binding to device |

### 6.2 Specific attack techniques the identity plane must resist

| Technique | Countermeasure |
|---|---|
| Golden/Silver Ticket (Kerberos) | Double KRBTGT reset (with replication wait between), monitor ticket anomalies (long lifetimes, RC4 downgrade) |
| Golden SAML / token forgery | Rotate federation signing certs, invalidate refresh tokens, monitor for tokens with no matching authentication event |
| Pass-the-Hash / Pass-the-Ticket | Credential Guard/LSA protection where possible, restrict NTLM, tier separation |
| DCSync / directory replication abuse | Alert on replication requests from non-DC hosts; remove replication rights from non-essential accounts |
| Insider abuse of valid privileges | Behavioral baselines, JIT privileges, session recording, dual approval on sensitive actions |
| Persistence (rogue admins, OAuth apps, MFA devices) | Audit and diff all privileged group members, app registrations, consent grants and registered MFA methods against baseline |

---

## 7. Live Ransomware Containment Architecture

Containment must work **without full isolation**, so it layers *identity*, *host*, *network* and *data* controls.

```mermaid
flowchart LR
    subgraph Detect["Detection Inputs"]
        EDR["EDR (modern hosts)"]
        NDR["NDR / flow logs (legacy hosts)"]
        IAMT["IdP and PAM telemetry"]
        FIM["File-integrity and canary files"]
    end
    subgraph Decide["Decision Layer"]
        SIEM["SIEM / UEBA correlation"]
        SOAR["SOAR playbooks (L1-L3 auto)"]
        IC["Incident Commander (L4+)"]
    end
    subgraph Act["Enforcement Layer"]
        ID["Identity: suspend / revoke / step-up"]
        HOST["Host: isolate / kill process / snapshot"]
        NET["Network: SDN/NGFW rules, DNS sinkhole"]
        DATA["Data: snapshot lock, replication pause, read-only mode"]
    end
    Detect --> SIEM --> SOAR --> Act
    SIEM --> IC --> Act
```

### 7.1 Containment layers

| Layer | Action | Notes |
|---|---|---|
| **Identity** | Suspend or step-up compromised accounts, revoke sessions, block risky sign-ins | First and fastest, since credentials are the propagation vector |
| **Host (modern)** | EDR network-isolate with a *management-channel allow-list* (EDR cloud + forensic collector only) | Preserves memory for forensics |
| **Host (legacy)** | Cannot rely on agents, so isolate at the switch port, hypervisor vNIC or SDN tag; restrict to clinical allow-list flows | Compensating control |
| **Network** | Block SMB/RDP/WinRM/SSH lateral paths; sinkhole known C2 domains; rate-limit anomalous east-west flows; egress filtering to stop exfiltration | Not full isolation |
| **Data** | Trigger storage snapshots with immutability lock; enable object-lock; switch high-value shares to read-only for non-clinical writers; pause replication of anomalous datasets | Protects last-known-good |
| **Deception** | Canary files, honey accounts and honeytokens placed in shares and directories | Early encryption and credential-abuse detection |

### 7.2 Clinical-safe quarantine

For any asset tagged **clinical-critical**, quarantine means:

1. Cut all flows **except** the allow-listed clinical flows (EHR ↔ DB, HL7/FHIR interfaces, PACS, device gateways).
2. Force access through an **inspecting proxy** (full logging).
3. Block outbound internet and all admin protocols.
4. Take a **crash-consistent snapshot** immediately for forensics.
5. If the host shows active encryption, stop the process/VM (power-state action approved by the Clinical Lead) and fail over to a verified replica.

---

## 8. Microsegmentation Enforcement Model

Segmentation is incomplete, so enforcement is applied in **waves by risk**, using whatever enforcement point exists (host firewall, hypervisor firewall, cloud security groups, NGFW, switch ACL).

### 8.1 Enforcement waves

| Wave | Target | Policy type | Timing |
|---|---|---|---|
| **W0** | Identity infrastructure, KMS/HSM, backup consoles | Strict allow-list, admin only via PAM | Within first hour |
| **W1** | Healthcare records platform and DBs | Application-tier allow-list (web→app→DB only on named ports) | 1 to 4 hours |
| **W2** | Management protocols across all zones (SMB, RDP, WinRM, SSH, WMI) | Default-deny, brokered exceptions | 1 to 4 hours |
| **W3** | Replication pipelines | Source/target pinning, mutual TLS, integrity-check gate | 4 to 12 hours |
| **W4** | Legacy zones | Front-door proxy or virtual patching plus flow allow-list | 12 to 48 hours |
| **W5** | General user/servers | Progressive tightening based on observed traffic | Days to weeks |

### 8.2 Safe enforcement method: "Monitor → Alert → Enforce"

```mermaid
flowchart LR
    M["Monitor mode<br/>(log would-be denies)"] --> V["Validate with app owner<br/>and Clinical Lead"] --> E["Enforce for<br/>selected flows"] --> R["Rollback timer<br/>(auto-revert if health check fails)"]
```

- Policies are generated from **observed flow data** (last 30 days baseline where available) and reviewed.
- **Health-check gating:** if clinical transaction success rate drops below threshold after a rule push, the change auto-rolls back.
- **Label-based policy** (role, environment, sensitivity) instead of IP-based, so it survives changes in hybrid and multi-region setups.
- **Identity-aware rules:** flows are permitted per *workload identity + user identity*, not per IP alone.
- Rules are written with **explicit deny-and-log** for known ransomware lateral movement patterns.

---

## 9. Credential Revocation and Reissuance Strategy

Because the attack rides valid credentials, revocation is **tiered and staged** to avoid an outage.

### 9.1 Priority tiers

| Tier | Credentials | Action | Sequence |
|---|---|---|---|
| **T0** | Domain/enterprise admin, IdP admin, PAM vault, KMS/HSM admin, cloud root/global admin, backup admin | Immediate suspend → rotate → reissue via re-bootstrap (Section 10) | First |
| **T1** | Accounts seen in attacker activity, insider account, accounts that logged onto compromised hosts | Suspend, revoke sessions, force re-auth, reset after forensic capture | Immediate |
| **T2** | Service accounts, API keys, CI/CD tokens, database credentials | Rotate in dependency order; move to managed identity or short-lived certs | Hours |
| **T3** | Clinicians and general staff | Session invalidation, token refresh, risk-based MFA re-registration | Staged waves (by risk and shift pattern) |
| **T4** | Patients / external portal identities | Monitor and step-up only unless compromise indicators appear | As needed |

### 9.2 Revocation checklist

- [ ] Invalidate refresh tokens and active sessions (IdP, cloud, VPN, SaaS)
- [ ] Revoke OAuth grants and suspicious app registrations
- [ ] Remove unknown MFA devices; review conditional-access changes
- [ ] Rotate KRBTGT twice (with replication interval between) *only when the clean identity plane is ready*
- [ ] Rotate federation signing certificates in a staged, dual-trust way
- [ ] Rotate database, application and vault secrets in dependency order
- [ ] Revoke and reissue certificates from compromised or suspect CAs
- [ ] Regenerate SSH keys and cloud access keys

### 9.3 Clinical continuity during revocation

- **Clinical break-glass workflow:** pre-approved, *time-limited, logged* emergency access for clinicians (for example, badge-tap + PIN + supervisor witness) so credential resets never block patient care.
- Rotations are scheduled around **shift changes**, with on-site "credential support desks" on wards.
- **Service-account rotation** uses dual-secret overlap (old and new valid briefly) to avoid breaking integrations, and the old secret is then killed.
- **Insider account handling** is separate: see Section 11 (do not tip off before evidence capture).

---

## 10. Secure Identity Re-Bootstrap Process

Goal: rebuild trust in identity **without taking IAM offline**, using a **parallel clean identity plane (blue/green)**.

```mermaid
flowchart TD
    A["Step 1: Establish out-of-band trust anchor<br/>(offline root CA, HSM quorum, break-glass FIDO2)"] --> B["Step 2: Build clean identity enclave (Green)<br/>New IdP/Directory in isolated management network<br/>from known-good images"]
    B --> C["Step 3: Selective identity import<br/>Import users and groups (not credentials, tokens, or SIDHistory)<br/>Diff and review privileged memberships"]
    C --> D["Step 4: Issue new credentials<br/>Phishing-resistant MFA (FIDO2) for admins first<br/>New signing keys and certificates"]
    D --> E["Step 5: Dual-trust cutover per application<br/>Green trusted alongside Blue; migrate app by app<br/>Clinical apps in maintenance windows with rollback"]
    E --> F["Step 6: Retire Blue trust<br/>Revoke federation trust to compromised plane<br/>Decommission after forensic imaging"]
```

### 10.1 Key controls

| Control | Detail |
|---|---|
| **Trust anchor** | New signing keys generated inside a *fresh HSM partition* with M-of-N quorum. The old key material is treated as exposed. |
| **Import hygiene** | Import identity *objects* only. **Never** import password hashes, tickets, tokens or unreviewed ACLs. Reset and re-enroll credentials. |
| **Admin bootstrap** | New Tier-0 admins are created only from PAWs on the clean enclave, bound to hardware keys. There is no reuse of old admin accounts. |
| **Federation cutover** | Applications are re-pointed to the Green IdP one at a time (SAML metadata/OIDC issuer swap). Each app gets a canary test group before the rest of its users. |
| **Verification** | Automated checks confirm that no Blue-issued tokens are accepted after cutover, and that no unexpected trust relationships exist. |
| **IAM availability** | Blue remains online in monitored, restricted mode until Green carries all traffic, so IAM is **never offline**. |

### 10.2 Break-glass model (identity-independent)

- 2 to 3 **local, hardware-key-protected emergency accounts** per critical platform, credentials in sealed physical custody, alarm on use.
- Not synced from the directory and not reachable from general networks.
- Used only if the primary and Green identity planes are both unavailable, and rotated after each use.

---

## 11. Insider Threat Isolation Workflow

Insider handling must balance **stopping harm** against **preserving evidence and legal defensibility**. Restricted circle: IC, Legal, HR, Forensics, Identity Lead.

```mermaid
flowchart TD
    A["Detect: anomalous privileged activity<br/>(UEBA / PAM / DLP alert)"] --> B["Validate quickly<br/>(rule out false positive, check for stolen credential vs. true insider)"]
    B --> C["Silent evidence capture<br/>Enhanced logging, session recording, snapshot mailbox/files/endpoints"]
    C --> D["Contain without tipping off<br/>Downgrade privileges silently, add step-up + JIT, restrict sensitive data scopes, route via monitored proxy"]
    D --> E{"Immediate risk to patients or data?"}
    E -- "Yes" --> F["Immediate L1 suspension + escort/badge disable<br/>(Legal and HR informed)"]
    E -- "No" --> G["Continue monitored containment until evidence is sufficient"]
    F --> H["Formal action: HR, Legal, law enforcement as needed"]
    G --> H
    H --> I["Post-action: credential purge, access review of insider's peers and managers, control fixes"]
```

**Principles**

- **Distinguish** a malicious insider from a compromised insider account (stolen credentials). The response differs: a compromised user needs support and reset, a malicious user needs a legal process.
- **Least-surprise containment:** reduce privileges to "just enough to work" but remove capability to destroy or exfiltrate (disable bulk export, delete rights, admin tools, removable media).
- **Chain of custody** for all evidence from the first capture.
- **Segregation of duties:** no single responder can act on the insider case alone. Two-person approvals, and the insider's own manager is not informed unless required.
- **Patient-safety carve-out:** if the insider is a clinician on shift, transition duties safely before restricting clinical access.
- Follow local employment and privacy law. HR and Legal approve every step that affects employment.

---

## 12. Behavioral Anomaly Detection Strategy

### 12.1 Multi-source telemetry (compensating for legacy blind spots)

| Source | Covers | Legacy compensation |
|---|---|---|
| IdP / directory / PAM logs | Authentication, privilege use, token issuance | Identity-layer visibility for *all* systems |
| EDR | Modern endpoints and servers | n/a |
| **NDR / network taps / flow logs / DNS logs** | Legacy hosts without agents | Detects scanning, lateral movement, C2, unusual SMB volume |
| Storage and file-server audit | Mass rename/encrypt patterns | Entropy and rename-rate detections at the file layer |
| Cloud control-plane logs | API abuse, new keys, snapshot deletion | n/a |
| DLP / proxy | Exfiltration | n/a |
| Deception assets | Canary files, honeytokens | Works with zero agent needed |

### 12.2 Detection use-cases

| Category | Example signal |
|---|---|
| **Ransomware behavior** | High-rate file modification with entropy increase; mass extension changes; shadow-copy or backup deletion; security-tool tampering |
| **Credential abuse** | Impossible travel; first-time admin tool use; logon to many hosts in a short time; service account interactive logon |
| **Privilege escalation** | Unexpected group additions; new replication rights; token or ticket anomalies; new federation trust |
| **Lateral movement** | SMB/RDP/WinRM fan-out from a single host; new host-to-host edges never seen in baseline graph |
| **Insider indicators** | Off-hours bulk record access; access to patients outside care relationship; unusual export volume; use of unapproved storage |
| **Exfiltration** | Large outbound transfers; DNS tunneling; connections to newly registered domains |

### 12.3 Analytics approach

1. **Baseline** per user, role, host and service (peer-group comparison) using UEBA.
2. **Graph analytics** on the access graph to spot new paths toward Tier-0 assets.
3. **Risk scoring** that combines identity risk, device posture and behavior. Scores drive *automatic* L1 to L3 actions.
4. **Tuning for incident mode:** temporarily lower thresholds on Tier-0 and clinical crown jewels, accepting a higher false-positive rate, and raise analyst staffing.
5. **Clinical false-positive protection:** clinician "break-glass" and emergency access patterns are whitelisted with heavy logging, not blocked.
6. **Feedback loop:** analyst dispositions retrain and tune rules every shift during the incident.

---

## 13. Forensic-Safe Containment

Containment and evidence preservation are designed together.

| Practice | Detail |
|---|---|
| **Order of volatility** | Capture memory and live network state first, then disk, then logs. EDR isolation (not power-off) keeps RAM intact. |
| **Snapshot before change** | Take hypervisor or cloud snapshots of affected VMs *before* remediation. Store in a write-once evidence vault. |
| **Preserve logs centrally** | Increase retention, replicate to an immutable, separate account/tenant (write-once), and hash-chain log batches. |
| **Chain of custody** | Every artifact is hashed (SHA-256), timestamped, and logged with collector and handler identity. |
| **Avoid tipping off** | Prefer network and identity throttling over noisy kills for the insider and advanced-attacker actors until evidence is captured. |
| **No "cleanup first"** | Do not reimage, delete malware or reset accounts on affected assets before imaging (unless active patient harm requires it, which is a documented exception). |
| **Separate forensic network** | Analysis systems are in an isolated enclave with no path to production identity. |
| **Legal hold** | Issued at T+0 to prevent deletion by retention policies. |
| **Time synchronization** | Record NTP offsets so timelines across on-prem, cloud and regions can be correlated. |

---

## 14. Immutable Backup Verification Method

Backup integrity is uncertain, so **each backup set is treated as untrusted** until it passes a multi-gate verification.

```mermaid
flowchart TD
    A["Identify candidate backup sets<br/>(by date, region, system)"] --> B["Gate 1: Immutability proof<br/>WORM / object-lock status, retention lock, no admin override, audit of delete/modify attempts"]
    B --> C["Gate 2: Integrity proof<br/>Hash/signature validation against independently stored catalog; verify catalog itself is untampered"]
    C --> D["Gate 3: Timeline bracketing<br/>Compare with earliest known compromise (dwell time) to select pre-compromise candidates"]
    D --> E["Gate 4: Malware and IOC scan in isolated sandbox<br/>(multi-engine, YARA/IOC, entropy checks)"]
    E --> F["Gate 5: Test restore in clean room<br/>Boot, run application health and data-consistency checks"]
    F --> G["Gate 6: Key availability check<br/>Confirm decryption keys are known-good and not exposed"]
    G --> H["Certify as 'Trusted Restore Point' (signed by 2 approvers)"]
```

### 14.1 Method details

| Gate | Check | Pass criteria |
|---|---|---|
| **1. Immutability** | Object-lock (compliance mode) or WORM appliance state; verify no policy shortening or unlock events in audit logs | Retention active; no unexplained admin changes |
| **2. Integrity** | Recompute hashes and compare with an *out-of-band* copy of the catalog (offline or separate tenant); verify backup software's own signatures | 100% match |
| **3. Timeline** | Use earliest indicator of compromise (IOC) date minus safety margin; also check for **dormant persistence** older than the incident | Backup predates initial access (with margin) |
| **4. Malware scan** | Mount read-only in sandbox; scan files, scripts, scheduled tasks, startup items, GPO/config artifacts | No IOCs; no anomalous high-entropy encrypted files |
| **5. Restore test** | Restore to isolated clean-room; run database consistency (checksums, referential integrity), application smoke tests, sample clinical record validation | Consistent and functional |
| **6. Key check** | Confirm the backup's encryption keys are from the clean key hierarchy or re-wrapped safely | Keys verified; no exposed material in use |

### 14.2 Additional protections

- **Prefer a 3-2-1-1-0 pattern:** 3 copies, 2 media types, 1 offsite, 1 immutable/air-gapped, **0** verification errors.
- Backup admin plane is separate from production identity (separate credentials, hardware MFA, no domain join).
- **Clinical data reconciliation:** reconcile restored data with **transaction logs and HL7/FHIR message archives** to replay legitimate changes after the restore point.
- If no fully clean backup exists, use **partial trust**: restore verified objects only, and rebuild the rest from source systems and logs.

---

## 15. Clean-Room Recovery Pipeline

A **clean room** is an isolated, freshly built environment with no trust relationship to the compromised estate.

```mermaid
flowchart LR
    subgraph CR["Clean Room (isolated enclave)"]
        B1["Known-good base images<br/>(golden, signed)"] --> B2["Rebuild: OS, hypervisor, platform<br/>via IaC from trusted repo"]
        B2 --> B3["Restore data from Trusted Restore Points"]
        B3 --> B4["Security validation:<br/>vuln scan, config baseline, IOC hunt, integrity checks"]
        B4 --> B5["Clinical validation:<br/>data consistency, app function, interface tests"]
    end
    B5 --> G["Promotion gate<br/>(dual approval: Security + Clinical)"]
    G --> P["Staged reconnection to production<br/>(canary → partial → full)"]
```

### 15.1 Pipeline stages

| Stage | Activities |
|---|---|
| **0. Preparation** | Build the enclave with its own identity (Green plane), own network, own logging. One-way data ingress through a scanning "airlock." |
| **1. Rebuild infrastructure** | Deploy from signed images and infrastructure-as-code from a *verified* repository (commit signatures checked; the repo credentials are rotated first). No lift-and-shift of old binaries or configs. |
| **2. Restore data** | Only from Trusted Restore Points (Section 14). Restore into read-only first, verify, then enable writes. |
| **3. Harden** | Apply CIS-style baselines, patch known exploited vulnerabilities, disable legacy protocols (SMBv1, NTLM where possible), enforce tiered admin. |
| **4. Validate** | Vulnerability and config scans, IOC/YARA hunting, integrity baselines, penetration test of the enclave, and **clinical user acceptance**. |
| **5. Promote** | Reconnect service-by-service under **enforced microsegmentation** and monitoring. Start with read-only clinical access, then full write. |
| **6. Monitor** | Enhanced monitoring for 30+ days (heightened detection thresholds, threat hunting for re-infection). |

### 15.2 Legacy systems (no telemetry)

- Rebuild if possible; if not, place behind **protocol-breaking proxies**, restrict to a fixed flow allow-list, and monitor via NDR and honeytokens.
- Treat as **untrusted-by-default** even after recovery, and record as risk-accepted with an owner and an end date.

---

## 16. Cross-Region Failover Security Validation

Failover must not simply **move the infection** or **replicate the damage**.

### 16.1 Pre-failover checklist (per region)

| Check | Description |
|---|---|
| **Replication integrity** | Confirm replica data predates compromise or has passed the Section 14 gates. Compare checksums and row counts across regions. |
| **Replication pause point** | Verify the replication link was paused (L6) *before* encrypted data was written; identify the last-known-good sequence number or LSN. |
| **Identity independence** | Target region uses the Green identity plane or a verified-clean replica with fresh keys. |
| **Key isolation** | Region-specific key hierarchy (KEK per region); confirm no exposure of the target region's keys. |
| **Network posture** | Segmentation policy from Section 8 is *already enforced* in the target region. |
| **Configuration drift** | IaC diff against baseline: no unexpected users, roles, security-group rules or trust relationships. |
| **Telemetry ready** | Logging, EDR/NDR and alerting active in the target region before cut-in. |

### 16.2 Failover validation flow

```mermaid
flowchart TD
    A["Select healthy region"] --> B["Pre-failover security checklist"]
    B --> C["Synthetic clinical transactions<br/>(read, write, HL7/FHIR, auth flows)"]
    C --> D["Shadow traffic / canary (1-5% of users)"]
    D --> E{"Security + clinical metrics healthy?"}
    E -- "Yes" --> F["Progressive traffic shift (25% → 50% → 100%)"]
    E -- "No" --> G["Rollback and investigate"]
    F --> H["Post-failover: hunt for IOCs, verify data integrity, confirm no cross-region trust from compromised region"]
```

### 16.3 Rules

- **One-way valve:** the compromised region's outbound replication stays blocked until re-certified.
- **No shared secrets across regions:** rotate any cross-region credential or trust relationship *before* failover.
- **DNS/traffic-manager** changes are performed by a small authorized group using PAM and recorded.
- **Failback** requires the same gates plus a data-reconciliation step to avoid split-brain and data loss.

---

## 17. Recovery Trust Chain Reconstruction

Trust is rebuilt **from the bottom up**, and each layer is verified before the next layer relies on it.

```mermaid
flowchart BT
    L1["Layer 1: Hardware and root of trust<br/>Firmware attestation, HSM, TPM, secure boot"] --> L2["Layer 2: Cryptographic roots<br/>New root/issuing CAs, new KMS hierarchy (KEK to DEK)"]
    L2 --> L3["Layer 3: Identity plane<br/>Green IdP/directory, PAM, federation trust"]
    L3 --> L4["Layer 4: Platform and infrastructure<br/>Hypervisors, OS images, network policy, logging"]
    L4 --> L5["Layer 5: Data<br/>Verified restore points, reconciliation with transaction logs"]
    L5 --> L6["Layer 6: Applications and clinical workflows<br/>Signed builds, tested interfaces"]
    L6 --> L7["Layer 7: Users and devices<br/>Re-enrolled, posture-checked"]
```

### 17.1 Encryption keys "partially exposed" strategy

| Action | Detail |
|---|---|
| **Assume exposure** | Treat any key that resided on, or was accessible from, compromised systems as burned. |
| **Envelope re-wrapping** | Generate a **new KEK** in the HSM/KMS, then re-wrap each DEK with the new KEK. This avoids re-encrypting all data at once and is fast. |
| **Prioritize** | Rotate first for: patient-data stores, backup encryption, TLS private keys, signing keys, federation certs. Then lower-tier systems. |
| **Full re-encryption** | For data where the *DEK itself* may be exposed, re-encrypt (rolling, background) starting with the most sensitive datasets. |
| **Certificates** | Revoke and reissue from the new CA. Publish revocation (CRL/OCSP) and confirm clients honor it. |
| **Crypto hygiene** | Key access logging, split knowledge and dual control, no key material in scripts or config files. |

### 17.2 Trust-chain evidence

Each layer produces a **signed attestation** (what was built, from which image, validated by whom, when). The set of attestations forms an **auditable trust ledger** used for regulators and post-incident review.

---

## 18. Operational Continuity Balancing

**99.99% availability allows roughly 4.4 minutes of downtime per month**, so changes must be **non-disruptive by design**.

### 18.1 Service tiers and behavior under incident

| Tier | Examples | Policy |
|---|---|---|
| **Tier A (life-critical)** | EHR read/write for active patients, medication systems, critical care interfaces, identity availability | Fail-operational; changes only with Clinical Lead approval; canary + auto-rollback |
| **Tier B (clinical support)** | Scheduling, labs and imaging archives, e-prescribing | Degraded mode allowed (read-only, delayed sync) |
| **Tier C (business)** | Billing, HR, analytics | May be suspended or isolated to protect A and B |

### 18.2 Techniques

- **Read-only clinical mode:** if writes are unsafe, switch the EHR to read-only and use paper or downtime procedures for new entries, then reconcile later.
- **Rolling changes:** apply security changes to one node, AZ or region at a time, keeping capacity for load.
- **Active-active with clean replicas:** maintain at least one verified-clean replica able to carry Tier A load.
- **Downtime procedures:** clinical staff have printed patient summaries, medication lists and manual workflows ready.
- **Change safety:** every containment action carries (a) expected impact, (b) health metric, (c) rollback trigger.
- **Decision rule:** *If a containment action risks patient safety more than the threat does, choose the less disruptive control* (for example, identity restriction and proxying instead of disconnecting a segment).
- **Capacity for security itself:** ensure logging, SOAR and analyst staffing scale, since incident load is higher.

### 18.3 Balancing table

| Decision | Security-leaning | Continuity-leaning | Chosen approach |
|---|---|---|---|
| Segment quarantine | Full cut | Do nothing | Clinical-safe quarantine (allow-listed flows only) |
| Credential reset | Reset all now | Delay | Tiered waves + break-glass access |
| Replication | Stop all | Keep all | Pause suspicious pipelines; keep verified clean flows |
| Legacy hosts | Power off | Leave open | Proxy + allow-list + NDR monitoring |
| IdP rebuild | Take offline | Leave compromised | Parallel Green plane and dual trust |

---

## 19. Regulatory Reporting Track

The regulatory clock has already started, so a **parallel compliance workstream** runs from T+0.

| Item | Approach |
|---|---|
| **Applicable regimes (examples, depends on jurisdiction)** | HIPAA Breach Notification Rule (US), GDPR (EU, 72-hour supervisory notification), India's CERT-In directions (incident reporting within 6 hours) and DPDP Act obligations, plus local health-sector rules and contractual obligations |
| **Owner** | Privacy Officer and Legal, with Forensics supplying facts |
| **Evidence** | Timeline of detection, containment and scope (records/patients affected, data types, encryption state), with all decisions logged |
| **Notification stages** | Initial notice (what is known), then updates as scope becomes clear, then final report and root-cause analysis |
| **Careful wording** | Facts only, with no speculation; clearly distinguish *confirmed* from *suspected* |
| **Patient/individual notice** | Prepared once exfiltration or unauthorized access to patient data is confirmed |
| **Third parties** | Notify insurers, business associates and law enforcement per contract and law |
| **Documentation** | Retain the trust-ledger (Section 17), backup verification records and forensic chain of custody |

---

## 20. Constraint-to-Control Traceability Matrix

| Constraint | Primary controls | Section |
|---|---|---|
| Patient data availability is life-critical | Tiered continuity, clinical-safe quarantine, break-glass, read-only mode, Clinical Lead veto | 5, 7, 9, 18 |
| No full network isolation | Identity-first containment, surgical L1 to L5 kill switches, flow allow-lists | 5, 7, 8 |
| IAM must remain online | Blue/green identity plane, dual trust, monitored Blue | 10 |
| Backup integrity uncertain | Six-gate verification, clean-room restore, log replay | 14, 15 |
| Attack via legitimate credentials | Tiered revocation, session and token invalidation, UEBA, JIT privileges | 6, 9, 12 |
| Encryption keys partially exposed | KEK rotation, DEK re-wrap, cert reissue | 17 |
| Legacy lacks telemetry | NDR, flow logs, identity logs, honeytokens, proxy fronting | 7, 12, 15 |
| Segmentation incomplete | Wave-based overlay enforcement, label-based policy | 8 |
| Regulatory clock started | Parallel compliance track, evidence discipline | 13, 19 |
| 99.99% SLA | Rolling changes, canary + auto-rollback, clean replicas | 16, 18 |

---

## 21. Metrics, Risks and Trade-offs

### 21.1 Success metrics

| Metric | Target (indicative) |
|---|---|
| Time to first containment (L1 to L3) | < 15 minutes from confirmed detection |
| Time to Tier-0 credential rotation | < 6 hours |
| Time to stop lateral propagation | < 1 hour |
| Clinical Tier A availability during incident | ≥ 99.99% (with downtime procedures counting as *continuity*) |
| Data loss (RPO) for clinical records | Minimal, reconciled from transaction logs and message archives |
| Backup trusted-restore-point coverage | 100% of Tier A systems |
| Post-recovery re-infection | Zero in 30-day monitoring window |

### 21.2 Key risks and mitigations

| Risk | Mitigation |
|---|---|
| Over-aggressive containment causes clinical harm | Clinical Lead veto, auto-rollback, clinical-safe quarantine |
| Attacker persists in identity plane after rotation | Diff-based audit of privileged objects, dual-plane cutover, threat hunting |
| Tipping off the insider | Silent evidence capture and least-surprise containment |
| Replication spreads encryption to clean regions | Early L6 pause, one-way valve, integrity gate |
| Poisoned or dormant-malware backups | Timeline bracketing, sandbox scanning, clean-room restore |
| Legacy blind spots hide activity | NDR, honeytokens, restrictive proxying |
| Responder fatigue and error | Shift rotation, checklists, pre-approved playbooks |

### 21.3 Post-incident actions

1. Complete the zero-trust migration using lessons learned (prioritized backlog).
2. Eliminate standing privileges; expand JIT and phishing-resistant MFA.
3. Retire or wrap legacy systems; mandate telemetry.
4. Move backups to an independent, immutable, separately-administered platform.
5. Run purple-team exercises and tabletop drills on this playbook twice a year.
6. Publish a blameless post-incident report and update the kill-switch hierarchy.

---

## Summary

The strategy is **identity-first, surgical and reversible**. The attackers' strongest weapon is legitimate credentials, so the defense concentrates on protecting and then rebuilding the identity plane in parallel, without ever taking IAM offline. Containment uses a graded kill-switch hierarchy with clinical safeguards. Recovery rests on verified immutable backups, a clean-room rebuild, and a bottom-up reconstruction of the trust chain, all while the compliance clock is handled in parallel and patient care continues throughout.

---

*This document is a design and educational exercise. Thresholds and timings are indicative and should be adapted to the organization's risk assessment, regulatory environment and clinical requirements.*

---

## Appendix A: Proof-of-Concept Run Output

Captured from an actual execution of `python3 simulation/run_demo.py` (synthetic data only).

```text
Run at 2026-09-28T06:03:36 | python 3.12.3

$ python backup_verify.py
First IOC: 2026-09-24  | safety margin: 7d

Backup      G1 lock  G2 hash  G3 time  G4 entropy  G5 restore  VERDICT
----------------------------------------------------------------------
2026-09-15  PASS     PASS     PASS     PASS        PASS        TRUSTED RESTORE POINT
2026-09-16  PASS     PASS     PASS     PASS        PASS        TRUSTED RESTORE POINT
2026-09-17  PASS     PASS     FAIL     PASS        PASS        REJECTED
2026-09-18  PASS     PASS     FAIL     PASS        PASS        REJECTED
2026-09-19  PASS     PASS     FAIL     PASS        PASS        REJECTED
2026-09-20  PASS     PASS     FAIL     PASS        PASS        REJECTED
2026-09-21  PASS     PASS     FAIL     PASS        PASS        REJECTED
2026-09-22  PASS     FAIL     FAIL     PASS        FAIL        REJECTED
2026-09-23  FAIL     PASS     FAIL     PASS        PASS        REJECTED
2026-09-24  PASS     PASS     FAIL     PASS        PASS        REJECTED
2026-09-25  PASS     PASS     FAIL     FAIL        PASS        REJECTED
2026-09-26  PASS     PASS     FAIL     FAIL        PASS        REJECTED

Trusted restore points: 2/12 -> latest usable: 2026-09-16

$ python detect_and_respond.py
=== DETECTIONS ===
[ALERT] INSIDER_BULK_ACCESS    subject=u_insider  score=80.6   410 records/h vs baseline 23
        -> actions: L1 | authority: AUTO (SOAR)
        -> Silent evidence capture first (Sec 11); L1 executes after snapshot
[ALERT] RANSOMWARE_BEHAVIOR    subject=srv_02     score=7.8    850 file mods/min, entropy 7.8
        -> actions: L3, L2* | authority: AUTO (SOAR)
        -> CLINICAL-SAFE QUARANTINE: allow-list EHR/HL7 flows only, snapshot, fail over to verified replica
[ALERT] RANSOMWARE_BEHAVIOR    subject=srv_05     score=7.9    900 file mods/min, entropy 7.9
        -> actions: L2, L3 | authority: AUTO (SOAR)
        -> Full host quarantine via EDR/switch-port isolation

[ESCALATE] >=2 hosts encrypting -> L4 (freeze privileged tier) + L6 (pause replication) proposed
           authority: TWO-PERSON APPROVAL (Incident Commander + Clinical Lead veto check)

Total alerts: 3 | injected anomalies: 3 | detected: 3 | false positives: 0 (computed over 21 users + 8 hosts)
```

![Simulation run](docs/run-screenshot.png)

## Appendix B: Source Code

<details>
<summary><code>simulation/backup_verify.py</code> (Section 14: multi-gate backup verification)</summary>

```python
"""Section 14 PoC: multi-gate verification of synthetic backup sets. No real data."""
import os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output"); os.makedirs(OUT, exist_ok=True)
import hashlib, math, os, random, json
from datetime import date, timedelta

random.seed(7)
FIRST_IOC = date(2026, 9, 24)          # earliest known compromise (simulated)
SAFETY_MARGIN = timedelta(days=7)      # dormant-persistence margin
ENTROPY_LIMIT = 7.5                    # bits/byte; text ~4-5, encrypted ~8

def entropy(b: bytes) -> float:
    if not b: return 0.0
    n = len(b); freq = [0]*256
    for x in b: freq[x] += 1
    return -sum(c/n*math.log2(c/n) for c in freq if c)

def text_blob(i): return (f"patient_record_{i} vitals ok; meds list; notes " * 60).encode()

def make_backup(day, encrypted=False, lock=True, tamper=False):
    files = {f"ehr/rec_{i}.dat": (os.urandom(3000) if encrypted and i % 2 == 0 else text_blob(i)) for i in range(8)}
    return {"date": day, "files": files, "object_lock": lock, "override_events": 0}

def build():
    d0 = date(2026, 9, 15)
    sets = [make_backup(d0 + timedelta(days=i)) for i in range(12)]
    catalog = {b["date"].isoformat(): {k: hashlib.sha256(v).hexdigest() for k, v in b["files"].items()} for b in sets}
    # simulate attacker effects AFTER catalog was stored out-of-band
    sets[7]["files"]["ehr/rec_3.dat"] = b"TAMPERED"                       # silent modification
    sets[8]["object_lock"] = False; sets[8]["override_events"] = 2        # retention lock disabled
    for i in (10, 11):                                                    # ransomware-encrypted content
        sets[i] = make_backup(sets[i]["date"], encrypted=True)
        catalog[sets[i]["date"].isoformat()] = {k: hashlib.sha256(v).hexdigest() for k, v in sets[i]["files"].items()}
    return sets, catalog

def verify(b, catalog):
    key = b["date"].isoformat(); r = {}
    r["G1_immutability"] = b["object_lock"] and b["override_events"] == 0
    r["G2_integrity"] = all(hashlib.sha256(v).hexdigest() == catalog[key][k] for k, v in b["files"].items())
    r["G3_timeline"] = b["date"] < FIRST_IOC - SAFETY_MARGIN
    r["G4_malware_entropy"] = all(entropy(v) < ENTROPY_LIMIT for v in b["files"].values())
    r["G5_restore_test"] = len(b["files"]) == 8 and all(len(v) > 100 for v in b["files"].values())
    return r

if __name__ == "__main__":
    sets, cat = build(); out = []; trusted = []
    print(f"First IOC: {FIRST_IOC}  | safety margin: {SAFETY_MARGIN.days}d\n")
    hdr = f"{'Backup':<12}{'G1 lock':<9}{'G2 hash':<9}{'G3 time':<9}{'G4 entropy':<12}{'G5 restore':<12}VERDICT"
    print(hdr); print("-"*len(hdr))
    for b in sets:
        r = verify(b, cat); ok = all(r.values())
        if ok: trusted.append(b["date"].isoformat())
        f = lambda x: "PASS" if x else "FAIL"
        print(f"{b['date']!s:<12}{f(r['G1_immutability']):<9}{f(r['G2_integrity']):<9}{f(r['G3_timeline']):<9}{f(r['G4_malware_entropy']):<12}{f(r['G5_restore_test']):<12}{'TRUSTED RESTORE POINT' if ok else 'REJECTED'}")
        out.append({"date": b["date"].isoformat(), **r, "trusted": ok})
    print(f"\nTrusted restore points: {len(trusted)}/{len(sets)} -> latest usable: {trusted[-1] if trusted else 'NONE'}")
    json.dump(out, open(os.path.join(OUT, "backup_verification.json"), "w"), indent=2)
```

</details>

<details>
<summary><code>simulation/detect_and_respond.py</code> (Sections 5, 11, 12: anomaly detection and kill-switch engine)</summary>

```python
"""Sections 5/11/12 PoC: behavioral anomaly detection -> kill-switch decision engine (synthetic events)."""
import os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output"); os.makedirs(OUT, exist_ok=True)
import random, statistics, math, json
from dataclasses import dataclass
random.seed(42)

# ---------- synthetic telemetry ----------
users = [f"clin_{i:02d}" for i in range(20)] + ["u_insider"]
def baseline():  # records accessed per hour, normal working hours
    return {u: [max(0, int(random.gauss(25, 6))) for _ in range(30)] for u in users}
hist = baseline()
today = {u: max(0, int(random.gauss(25, 6))) for u in users}
today["u_insider"] = 410                      # off-hours bulk patient-record access
hosts = {f"srv_{i:02d}": {"mods_per_min": random.randint(5, 40), "entropy": round(random.uniform(4.2, 5.4), 2), "clinical": i in (1, 2)} for i in range(8)}
hosts["srv_05"] = {"mods_per_min": 900, "entropy": 7.9, "clinical": False}   # ransomware-like burst
hosts["srv_02"] = {"mods_per_min": 850, "entropy": 7.8, "clinical": True}    # same, on a clinical host

@dataclass
class Alert: kind: str; subject: str; score: float; detail: str; clinical: bool = False

# ---------- detection ----------
alerts = []
for u, series in hist.items():
    mu, sd = statistics.mean(series), statistics.pstdev(series) or 1
    z = (today[u] - mu) / sd
    if z > 4: alerts.append(Alert("INSIDER_BULK_ACCESS", u, round(z, 1), f"{today[u]} records/h vs baseline {mu:.0f}"))
for h, m in hosts.items():
    if m["mods_per_min"] > 300 and m["entropy"] > 7.5:
        alerts.append(Alert("RANSOMWARE_BEHAVIOR", h, m["entropy"], f"{m['mods_per_min']} file mods/min, entropy {m['entropy']}", m["clinical"]))

# ---------- kill-switch decision engine (Section 5) ----------
LEVELS = {"L1": "Suspend identity + revoke sessions", "L2": "Quarantine host/workload",
          "L3": "Block lateral protocol (SMB/RDP/WinRM)", "L4": "Freeze privileged tier"}
def decide(a: Alert):
    if a.kind == "INSIDER_BULK_ACCESS":
        return ["L1"], "Silent evidence capture first (Sec 11); L1 executes after snapshot"
    if a.kind == "RANSOMWARE_BEHAVIOR":
        if a.clinical:
            return ["L3", "L2*"], "CLINICAL-SAFE QUARANTINE: allow-list EHR/HL7 flows only, snapshot, fail over to verified replica"
        return ["L2", "L3"], "Full host quarantine via EDR/switch-port isolation"
    return ["L0"], "Monitor"

print("=== DETECTIONS ===")
log = []
for a in alerts:
    levels, note = decide(a)
    approval = "AUTO (SOAR)" if all(l.strip("*") in ("L1", "L2", "L3") for l in levels) else "TWO-PERSON APPROVAL"
    print(f"[ALERT] {a.kind:<22} subject={a.subject:<10} score={a.score:<6} {a.detail}")
    print(f"        -> actions: {', '.join(levels)} | authority: {approval}\n        -> {note}")
    log.append({**a.__dict__, "actions": levels, "authority": approval, "note": note})
# propagation-stopping escalation check
if sum(1 for a in alerts if a.kind == "RANSOMWARE_BEHAVIOR") >= 2:
    print("\n[ESCALATE] >=2 hosts encrypting -> L4 (freeze privileged tier) + L6 (pause replication) proposed")
    print("           authority: TWO-PERSON APPROVAL (Incident Commander + Clinical Lead veto check)")
    log.append({"escalation": ["L4", "L6"], "authority": "TWO-PERSON APPROVAL"})
json.dump(log, open(os.path.join(OUT, "detection_and_response.json"), "w"), indent=2)
injected = {"u_insider", "srv_05", "srv_02"}
raised = {a.subject for a in alerts}
print(f"\nTotal alerts: {len(alerts)} | injected anomalies: {len(injected)} | detected: {len(raised & injected)} | false positives: {len(raised - injected)} (computed over 21 users + 8 hosts)")
```

</details>

<details>
<summary><code>simulation/run_demo.py</code> (runner)</summary>

```python
import os, subprocess, sys, datetime
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "output")
os.makedirs(OUT, exist_ok=True)
with open(os.path.join(OUT, "run_log.txt"), "w") as f:
    f.write(f"Run at {datetime.datetime.now().isoformat(timespec='seconds')} | python {sys.version.split()[0]}\n\n")
    for s in ("backup_verify.py", "detect_and_respond.py"):
        f.write(f"$ python {s}\n")
        r = subprocess.run([sys.executable, os.path.join(HERE, s)], capture_output=True, text=True, cwd=HERE)
        f.write(r.stdout + r.stderr + "\n"); print(r.stdout, r.stderr)
```

</details>

## Appendix C: Machine-Readable Results

<details>
<summary><code>simulation/output/backup_verification.json</code></summary>

```json
[
  {
    "date": "2026-09-15",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": true,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": true
  },
  {
    "date": "2026-09-16",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": true,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": true
  },
  {
    "date": "2026-09-17",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": false
  },
  {
    "date": "2026-09-18",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": false
  },
  {
    "date": "2026-09-19",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": false
  },
  {
    "date": "2026-09-20",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": false
  },
  {
    "date": "2026-09-21",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": false
  },
  {
    "date": "2026-09-22",
    "G1_immutability": true,
    "G2_integrity": false,
    "G3_timeline": false,
    "G4_malware_entropy": true,
    "G5_restore_test": false,
    "trusted": false
  },
  {
    "date": "2026-09-23",
    "G1_immutability": false,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": false
  },
  {
    "date": "2026-09-24",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": true,
    "G5_restore_test": true,
    "trusted": false
  },
  {
    "date": "2026-09-25",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": false,
    "G5_restore_test": true,
    "trusted": false
  },
  {
    "date": "2026-09-26",
    "G1_immutability": true,
    "G2_integrity": true,
    "G3_timeline": false,
    "G4_malware_entropy": false,
    "G5_restore_test": true,
    "trusted": false
  }
]
```

</details>

<details>
<summary><code>simulation/output/detection_and_response.json</code></summary>

```json
[
  {
    "kind": "INSIDER_BULK_ACCESS",
    "subject": "u_insider",
    "score": 80.6,
    "detail": "410 records/h vs baseline 23",
    "clinical": false,
    "actions": [
      "L1"
    ],
    "authority": "AUTO (SOAR)",
    "note": "Silent evidence capture first (Sec 11); L1 executes after snapshot"
  },
  {
    "kind": "RANSOMWARE_BEHAVIOR",
    "subject": "srv_02",
    "score": 7.8,
    "detail": "850 file mods/min, entropy 7.8",
    "clinical": true,
    "actions": [
      "L3",
      "L2*"
    ],
    "authority": "AUTO (SOAR)",
    "note": "CLINICAL-SAFE QUARANTINE: allow-list EHR/HL7 flows only, snapshot, fail over to verified replica"
  },
  {
    "kind": "RANSOMWARE_BEHAVIOR",
    "subject": "srv_05",
    "score": 7.9,
    "detail": "900 file mods/min, entropy 7.9",
    "clinical": false,
    "actions": [
      "L2",
      "L3"
    ],
    "authority": "AUTO (SOAR)",
    "note": "Full host quarantine via EDR/switch-port isolation"
  },
  {
    "escalation": [
      "L4",
      "L6"
    ],
    "authority": "TWO-PERSON APPROVAL"
  }
]
```

</details>

## Appendix D: How to Reproduce

```bash
git clone <your-repo-url>
cd <your-repo>
python3 simulation/run_demo.py     # Python 3.8+, standard library only
```

Note: all data in the simulation is synthetic. It demonstrates the design's decision logic and does not represent a real incident or real malware.
